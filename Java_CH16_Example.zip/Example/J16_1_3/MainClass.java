import java.util.*;
class  MainClass{
	public static void main(String[] args){
		ArrayList<Employee> schedule = new ArrayList<Employee>();

		Employee e1 = new Employee("K12345678", "Jack", 20, "�k��", "048679", 40000);
		Employee e2 = new Employee("K00000000", "Eric", 35, "�k��", "044000", 50000);
		schedule.add(e1);
		schedule.add(e2);

		Cat c = new Cat("Cookie");
		schedule.add(c);


	}
}
