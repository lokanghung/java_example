class Employee extends Person implements Comparable<Employee>{

	String employeeID;
	int    salary;


	Employee(String id, String name, int age, String gender, String employeeID, int salary){
		this.id = id;
		this.name = name;
		this.age = age;
		this.gender = gender;
		this.employeeID = employeeID;
		this.salary = salary;
	}

	double getBonus(){
		return 1*salary;
	}

	public int compareTo(Employee e){
		if(this.salary > e.salary) return 1;
		if(this.salary < e.salary) return -1;

		return 0;
	}


}
