import java.util.*;
class  MainClass{
	public static void main(String[] args){

		Room<Employee> r1 = new Room<Employee> ();
		r1.add(new Employee("K12345678", "Jack", 20, "�k��", "048679", 40000));
		r1.add(new Programmer("K00000000", "Eric", 25, "�k��", "041121", 45000));


		Room<Dog> r2 = new Room<Dog> ();
		r2.add(new Dog("Coopy"));


		Room<Cat> r3 = new Room<Cat> ();
		r3.add(new Cat("Cookie"));
	}
}
