import java.util.*;
class  MainClass{
	public static void main(String[] args){
		ArrayList<Employee> schedule = new ArrayList<Employee>();

		Programmer e1 = new Programmer ("K12345678", "Jack", 20, "�k��", "048679", 40000);
		Tester     e2 = new Tester("K00000000", "Eric", 35, "�k��", "044000", 50000);
		Artist     e3 = new Artist("K00000000", "Marry", 23, "�k��", "045000", 35000);


		schedule.add(e1);
		schedule.add(e2);
		schedule.add(e3);


		for(Employee e : schedule){
			if(e instanceof Programmer)
				((Programmer)e).code();

			if(e instanceof Tester)
				((Tester)e).test();

			if(e instanceof Artist)
				((Artist)e).draw();
		}
	}
}
