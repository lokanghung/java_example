class  Programmer extends Employee{
	Programmer(String id, String name, int age, String gender, String employeeID, int salary){
		super(id, name, age, gender, employeeID, salary);
	}

	void code(){
		System.out.println("��"+ name + "�g�F�@��{��");
	}
	void debug(){
		System.out.println("��"+ name + "���h�@��Bug");
	}

	double getBonus(){return 4*salary;}
}
