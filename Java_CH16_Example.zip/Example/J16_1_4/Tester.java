class  Tester extends Employee{
	Tester(String id, String name, int age, String gender, String employeeID, int salary){
		super(id, name, age, gender, employeeID, salary);
	}

	void test(){
		System.out.println("��"+ name + "���է��@�Өt��");
	}

	double getBonus(){return 1.5*salary;}
}
