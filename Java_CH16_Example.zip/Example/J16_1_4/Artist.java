class Artist extends Employee{
	Artist(String id, String name, int age, String gender, String employeeID, int salary){
		super(id, name, age, gender, employeeID, salary);
	}

	void  draw(){
		System.out.println("��"+ name + "�e���@�T�e");
	}
	double getBonus(){return 3*salary;}

}
