import  java.util.*;

class Room <T  extends  Employee>{

	T manager;
	private List<T> emps = new ArrayList<T>();

	boolean add(T e){
		return emps.add(e);
	}

	T get(int index){
		return emps.get(index);
	}

	boolean remove(T e){
		return emps.remove(e);
	}
	int size(){    return emps.size();  }
}
