import java.util.*;
class  MainClass{
	public static void main(String[] args){

		List<Programmer> ps = new ArrayList<Programmer>();
		ps.add(new Programmer("K12345678", "Jack", 20, "�k��", "048679", 40000));
		ps.add(new Programmer("K00000000", "Eric", 25, "�k��", "041121", 45000));
		Boss b = new Boss();
		b.pay(ps);
	}
}
