import java.util.*;
class Boss{

	public void pay(List<? extends Employee> emps){
		emps.add(new Tester("K11111111", "Mary", 18, "�k��", "050021", 30000));
	}
}
