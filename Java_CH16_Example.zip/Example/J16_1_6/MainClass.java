import java.util.*;
class  MainClass{
	public static void main(String[] args){
		ArrayList<Employee> schedule = new ArrayList<Employee>();
		List<Employee> l = schedule;
	}
}
