class Cat{
	String name;
	Cat(String name){this.name = name;}
}
