class Dog{
	String name;
	Dog(String name){this.name = name;}
}
