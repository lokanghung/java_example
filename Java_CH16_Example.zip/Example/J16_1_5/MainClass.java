import java.util.*;
class  MainClass{
	public static void main(String[] args){
		ArrayList<Object> schedule = new ArrayList<Employee>();

		schedule.add(new Employee());
		schedule.add(new Dog());
	}
}
