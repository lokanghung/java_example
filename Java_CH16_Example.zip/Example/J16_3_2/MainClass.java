import java.util.*;
class  MainClass{
	public static void main(String[] args){

		Room<Employee> r1 = new Room<Employee> ();
		Room<Programmer> r2 = new Room< Programmer>();
		Room<Tester> r3 = new Room< Tester>();
		Room<Artist> r4 = new Room< Artist>();


		Room<Dog> r5 = new Room<Dog> ();
		Room<Cat> r6 = new Room<Cat> ();

	}
}
