import java.util.*;
class  MainClass{
	public static void main(String[] args){

		List<Programmer> ps = new ArrayList<Programmer>();
		ps.add(new Programmer("K12345678", "Jack", 20, "�k��", "048679", 40000));
		ps.add(new Programmer("K00000000", "Eric", 25, "�k��", "041121", 45000));


		List<Tester> ts = new ArrayList< Tester >();
		ts.add(new Tester("K11111111", "Mary", 18, "�k��", "050021", 30000));


		List<Artist> as = new ArrayList< Artist >();
		as.add(new Artist("K22222222", "Jack", 19, "�k��", "051212", 42000));

		Boss b = new Boss();
		b.pay(ps);
		b.pay(ts);
		b.pay(as);

	}
}
