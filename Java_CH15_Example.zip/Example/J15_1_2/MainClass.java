import java.util.*;
class MainClass{
  public static void main(String[] args){
	ArrayList schedule = new ArrayList();
	schedule.add("Jack");
	schedule.add("Jason");
	schedule.add("Mary");
	schedule.add("Jack");

	System.out.println(schedule.get(0));
	System.out.println(schedule.get(1));
	System.out.println(schedule.get(2));


	schedule.set(0, "Eric");
	System.out.println(schedule.get(0));
  }
}
