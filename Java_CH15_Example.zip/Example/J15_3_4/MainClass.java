import java.util.*;
class MainClass{
	public static void main(String[] args){
		LinkedList schedule = new LinkedList();

		schedule.offer("Jack");
		schedule.offer ("Jason");
		schedule.offer ("Mary");
		schedule.offer("Eric");

		System.out.println(schedule.peek());
		System.out.println(schedule.peek());

		Object s = null;
		while(  (s = schedule.poll())  !=  null){
			System.out.println(s);
		}
	}
}
