import java.util.*;
class MainClass{
	public static void main(String[] args){
		HashMap table = new HashMap();

		table.put("ID", "K123456789");
		table.put("EmployeeID", "K123456789");

		System.out.println(table.get("ID"));
		System.out.println(table.get("EmployeeID"));

		table.put("EmployeeID", "048679");
		System.out.println(table.get("EmployeeID"));
	}
}
