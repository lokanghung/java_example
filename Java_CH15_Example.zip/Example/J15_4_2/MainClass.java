import java.util.*;
class MainClass{
	public static void main(String[] args){
		HashMap table = new HashMap();

		table.put("ID", "K123456789");
		table.put("Name", "Jack");
		table.put("Age", 20);
		table.put("Gender", "�k��");
		table.put("EmployeeID", "048679");
		table.put("Salary", 4000);

		System.out.println(table.get("ID"));
		System.out.println(table.get("Name"));
		System.out.println(table.get("Age"));
		System.out.println(table.get("Gender"));
		System.out.println(table.get("EmployeeID"));
		System.out.println(table.get("Salary"));
	}
}
