import java.util.*;
	class MainClass{
	public static void main(String[] args){
		HashMap table = new HashMap();

		table.put("ID", "K123456789");
		table.put("Name", "Jack");
		table.put("Age", 20);
		table.put("Gender", "�k��");
		table.put("EmployeeID", "048679");
		table.put("Salary", 4000);

		Set keys = table.keySet();

		for(Object key : keys){
			System.out.print(key + "�G");
			System.out.println(table.get(key));
		}
	}
}
