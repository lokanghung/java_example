import java.util.*;
class MainClass{
  public static void main(String[] args){

	Employee e1 = new Employee("K12345678", "Jack", 20, "�k��", "048679", 40000);
	Employee e2 = new Employee("K12345678", "Jack", 25, "�k��", "048679", 50000);

	HashSet employees = new HashSet();

	employees.add(e1);
	employees.add(e2);

	Employee  temp = null;

	for(Object o : employees){
		temp = (Employee)o;
		System.out.println(temp.id);
	}

  }
}
