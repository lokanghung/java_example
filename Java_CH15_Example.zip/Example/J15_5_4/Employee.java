class Employee extends Person{

  String employeeID;
  int    salary;


  public Employee(String pID, String pName, int pAge, String pGender, String pEmployeeID, int pSalary){
  	id = pID;
  	name = pName;
  	age = pAge;
  	gender = pGender;
  	employeeID = pEmployeeID;
  	salary = pSalary;
  }


  public boolean equals(Object  o){

     if(o instanceof Employee == false) return false;


     Employee e2 = (Employee) o;

     if(this.id == e2.id)
          return  true;
       else
     	   return false;
  }

   public int  hashCode(){
    return id.length();
  }

}
