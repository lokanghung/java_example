import java.util.*;
class MainClass{
	public static void main(String[] args){
		ArrayList employees = new ArrayList();
		employees.add("Jason");
		employees.add("Mary");
		employees.add("Alex");
		employees.add("Jack");
		employees.add("Mary");


		for(Object o : employees){
		 System.out.println(o);
		}


	}
}
