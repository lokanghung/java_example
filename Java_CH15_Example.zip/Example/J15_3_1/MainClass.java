import java.util.*;
class MainClass{
	public static void main(String[] args){
		TreeSet scores = new TreeSet();
		scores.add(3);
		scores.add(5);
		scores.add(2);
		scores.add(2);
		scores.add(4);


		for(Object o : scores){
			System.out.println(o);
		}
	}
}
