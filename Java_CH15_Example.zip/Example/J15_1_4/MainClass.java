import java.util.*;
class MainClass{
  public static void main(String[] args){
	ArrayList schedule = new ArrayList();

	schedule.add("Jack");
	schedule.add("Jason");
	schedule.add("Mary");
	schedule.add("Alex");
	schedule.add("Jack");
	schedule.add("Mary");

	int s = schedule.size();

	for(int i=0; i<s; i++){
		System.out.println(schedule.get(i));
	}
  }
}
