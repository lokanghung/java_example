import java.util.*;
	class MainClass{
	public static void main(String[] args){
		ArrayList schedule = new ArrayList();
		schedule.add("Jason");
		schedule.add("Mary");
		schedule.add("Alex");
		schedule.add("Jack");
		schedule.add("Mary");

		String name;
		Iterator i = schedule.iterator();

		while( i.hasNext() ){
			name =  (String)  i.next();
			System.out.println(name);
		}
	}
}
