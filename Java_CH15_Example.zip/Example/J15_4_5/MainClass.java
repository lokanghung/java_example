import java.util.*;
class MainClass{
	public static void main(String[] args){
		HashMap table = new HashMap();

		table.put("ID", "K123456789");
		table.put("Name", "Jack");
		table.put("Age", 20);
		table.put("Gender", "�k��");
		table.put("EmployeeID", "048679");
		table.put("Salary", 4000);

		Collection vals = table.values();

		for(Object val : vals){
			System.out.println(val);
		}
	}
}
