import java.util.*;
class MainClass{
	public static void main(String[] args){
		PriorityQueue scores = new PriorityQueue();
		scores.offer(3);
		scores.offer(5);
		scores.offer(2);
		scores.offer(2);
		scores.offer(4);
		Object  s = null;


		while(  (s = scores.poll())  !=  null){
			System.out.println(s);
		}
	}
}
