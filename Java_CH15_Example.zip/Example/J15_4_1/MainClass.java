import java.util.*;
class MainClass{
	public static void main(String[] args){
		ArrayList cols = new ArrayList();
		cols.add("ID");
		cols.add("Name");
		cols.add("Age");
		cols.add("Gender");
		cols.add("Salary");
		ArrayList vals = new ArrayList();
		vals.add("K123456789");
		vals.add("Jack");
		vals.add(20);
		vals.add("�k��");
		vals.add(40000);

		for(int i=0; i<cols.size(); i++){
			System.out.print(cols.get(i));

			System.out.println(vals.get(i));
		}
	}
}
