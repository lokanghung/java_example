class Person{
String id, name, gender;
int age;
}
