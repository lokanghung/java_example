class Employee extends Person{

  String employeeID;
  int    salary;


  public Employee(String pID, String pName, int pAge, String pGender, String pEmployeeID, int pSalary){
  	id = pID;
  	name = pName;
  	age = pAge;
  	gender = pGender;
  	employeeID = pEmployeeID;
  	salary = pSalary;
  }

}
