class  MainClass{
	public static void main(String[] args){

		String[] schedule = new String[6];

		schedule[0] = "Jack";
		schedule[1] = "Jason";
		schedule[2] = "Mary";
		schedule[3] = "John";
		schedule[4] = "Eric";
		schedule[5] = "Jack";

		schedule[6] = "Eric";
	}
}
