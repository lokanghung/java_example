import java.util.*;
class MainClass{
	public static void main(String[] args){
		TreeSet employees = new TreeSet();
		employees.add("Jason");
		employees.add("Mary");
		employees.add("Alex");
		employees.add("Jack");
		employees.add("Mary");


		for(Object o : employees){
		 	System.out.println(o);
		}



	}
}
