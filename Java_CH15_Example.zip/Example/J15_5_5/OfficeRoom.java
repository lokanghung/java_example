class OfficeRoom{
	String id;
	public OfficeRoom(String id){this.id = id;}
}
