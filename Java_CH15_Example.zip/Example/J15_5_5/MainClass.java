import java.util.*;
class MainClass{
  public static void main(String[] args){

	Employee e1 = new Employee("K12345678", "Jack", 20, "�k��", "048679", 40000);
	OfficeRoom r1 = new OfficeRoom("R001");
	OfficeRoom r2 = new OfficeRoom("R002");

	HashMap workArea = new HashMap();

	workArea.put(e1, r1);
	workArea.put(e1, r2);

	OfficeRoom temp = (OfficeRoom)workArea.get(e1);
	System.out.println(temp.id);


  }
}
