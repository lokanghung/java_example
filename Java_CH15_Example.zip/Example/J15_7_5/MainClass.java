import java.util.*;
class MainClass{
  public static void main(String[] args){

     Employee e1 = new Employee("K12345678", "Jack", 20, "�k��", "048679", 40000);
     Employee e2 = new Employee("K00000000", "Eric", 25, "�k��", "041121", 45000);
	 Employee e3 = new Employee("K11111111", "Mary", 18, "�k��", "050021", 30000);
	 Employee e4 = new Employee("K22222222", "Jack", 19, "�k��", "051212", 42000);
	 Employee[] ary = new Employee[4];
	 ary[0] = e1;
	 ary[1] = e2;
	 ary[2] = e3;
	 ary[3] = e4;

	 for(Object o : ary){
		Employee e = (Employee)o;
		System.out.print(e.name + "�G");
		System.out.println(e.salary);
	  }


  }
}
