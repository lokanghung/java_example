import java.util.*;
class MainClass{
  public static void main(String[] args){
	ArrayList schedule = new ArrayList();

	schedule.add("Jack");
	schedule.add("Jason");
	schedule.add("Mary");

	schedule.remove(0);
	schedule.remove("Mary");
	System.out.println(schedule.get(0));

  }
}
