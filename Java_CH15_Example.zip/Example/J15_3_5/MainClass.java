import java.util.*;
class MainClass{
	public static void main(String[] args){
		PriorityQueue scores = new PriorityQueue();
		scores.offer(3);
		scores.offer(5);
		scores.add(2);
		scores.add(2);
		scores.add(4);


		Iterator i = scores.iterator();
		while( i.hasNext() ){
			System.out.println(i.next());
		}

		Object s=null;
		while(  (s = scores.poll())  !=  null){
			System.out.println(s);
		}
	}
}
