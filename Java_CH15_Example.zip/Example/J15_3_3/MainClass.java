import java.util.*;
class MainClass{
	public static void main(String[] args){
		PriorityQueue scores = new PriorityQueue();
		scores.offer(3);
		scores.offer(5);
		scores.offer(2);
		scores.offer(2);
		scores.offer(4);


		System.out.println(scores.peek());
		System.out.println(scores.peek());
		System.out.println(scores.peek());
		System.out.println(scores.peek());
		System.out.println(scores.peek());
		System.out.println(scores.peek());

	}
}
