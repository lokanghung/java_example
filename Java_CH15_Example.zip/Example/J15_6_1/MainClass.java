import java.util.*;
class MainClass{
  public static void main(String[] args){

     Employee e1 = new Employee("K12345678", "Jack", 20, "�k��", "048679", 40000);
     Employee e2 = new Employee("K00000000", "Eric", 25, "�k��", "041121", 45000);

	 PriorityQueue q = new PriorityQueue();
	 q.offer(e1);
	 q.offer(e2);
  }
}
