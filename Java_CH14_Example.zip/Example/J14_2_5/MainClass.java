import java.io.*;
class MainClass{
  public static void main(String[] args){
		File f = new File("c:/MySystem/Male/K12345678.txt");
 		try{ f.createNewFile();}catch(IOException e){ }
		try{
			FileWriter w = new FileWriter( f );
			w.write("ID    �GK12345678" + "\n");
			w.write("Name �GJack" + "\n");
			w.write("Gender�G�k" + "\n");
			w.write("Age   �G20" + "\n");

			w.close();

			w.write("Age   �G20" + "\n");

		}catch(IOException e){
			System.out.println(e);
		}
	}
}
