import java.io.*;
class MainClass{
  public static void main(String[] args){
		File f = new File("c:/MySystem/Male/K12345678.txt");
		try{
				f.createNewFile();
				FileWriter  w = new FileWriter( f );

				BufferedWriter bw = new BufferedWriter( w );
				bw.write("ID    �GK12345678" );
				bw.newLine();
				bw.write("Name �GJack" );
				bw.newLine();
				bw.write("Gender�G�k");
				bw.newLine();
				bw.write("Age   �G20");
				bw.newLine();
				bw.close();
		}catch(IOException e){
			System.out.println(e);
		}
	}
}
