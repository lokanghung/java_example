import java.io.*;

class Boss implements Serializable{
  private String name;
  Boss(String name){
    this.name = name;
  }
}
