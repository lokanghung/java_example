import java.io.*;
class MainClass{
	public static void main(String[] args){
		File f = new File("c:/MySystem/Male/K12345678.txt");
		try{
			FileInputStream is = new FileInputStream( f );


			ObjectInputStream ois = new ObjectInputStream (is);
			Person p = (Person) ois.readObject();

			ois.close();
		}catch(IOException e){
			System.out.println(e);
		}catch(ClassNotFoundException e1){
			System.out.println(e1);
		}
	}
}
