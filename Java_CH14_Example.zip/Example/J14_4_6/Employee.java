

class Employee extends Person{

	private String employeeID;
	private int    salary;
	Boss  boss;

	Employee(String id, String name, String gender,
		int age, String employeeID, int salary, Boss b){
		super(id, name, gender, age);
		this. employeeID = employeeID;
		this.salary      = salary;
		this.boss = b;
	}

	String getEmployeeID(){return employeeID;}
	void  setEmployeeID(String s){ employeeID =s;}
	int   getSalary(){return salary;}
	void  setSalary(int i){ salary =i;}
}
