import java.io.*;
class MainClass{
	public static void main(String[] args){
		File f = new File("c:/MySystem/Male/K12345678.txt");
		try{
			f.createNewFile();
			FileOutputStream os = new FileOutputStream( f );
			ObjectOutputStream oos = new ObjectOutputStream (os);

			Boss b = new Boss("Frank");

			Employee e1 = new Employee(
			"K12345678", "Jack", "�k", 20, "048679", 40000,  b );

			oos.writeObject(e1);
			oos.close();

		}catch(IOException e){
			System.out.println(e);
		}
	}
}
