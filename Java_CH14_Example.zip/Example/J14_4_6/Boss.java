class Boss {
  private String name;
  Boss(String name){
    this.name = name;
  }
}
