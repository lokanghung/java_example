import java.io.*;

class Person implements Serializable{

	private String id;
	private String name;
	private String gender;
	private int    age;

	Person(String id, String name, String gender, int age){
		this.id     = id;
		this.name  = name;
		this.gender = gender;
		this.age   = age;
	}
	String getID(){return id;}
	void  setID(String s){id=s;}
	String getName(){return name;}
	void  setName(String s){name=s;}
	String getGender(){return gender;}
	void  setGender(String s){gender=s;}
	int   getAge(){return age;}
	void  setAge(int i){age=i;}
}
