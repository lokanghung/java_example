import java.io.*;
class MainClass{
	public static void main(String[] args){
		File f = new File("c:/MySystem/Male/K12345678.txt");
		try{
			FileReader r = new FileReader( f );

			int  i ;
			while( ( i  = r.read()) != -1){
				System.out.print(  (char)  i   );
			}
			r.close();

		}catch(FileNotFoundException e1){
			System.out.println("�䤣����w���ɮ�");
		}catch(IOException e2){
			System.out.println("IO�o�Ͳ��`");
		}
	}
}
