import java.io.*;
class MainClass{
	public static void main(String[] args){

		File f = new File("c:/MySystem/Male/K12345678.txt");

		try{ f.createNewFile();}catch(IOException e){ }

		try{
			PrintWriter w = new PrintWriter( f );
			w.println("ID    �GK12345678" );
			w. println("Name �GJack");
			w. println("Gender�G�k");
			w. println("Age   �G20");
			w.close();

		}catch(IOException e){ }
	}
}
