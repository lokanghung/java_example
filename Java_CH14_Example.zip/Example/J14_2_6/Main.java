import java.io.*;

class MainClass{
	public static void main(String[] args){


		File f = new File("c:/MySystem/Male/K12345678.txt");


		try{
			FileReader r = new FileReader( f );
		}catch(FileNotFoundException e){
			System.out.println("�䤣����w���ɮ�");
		}

	}
}
