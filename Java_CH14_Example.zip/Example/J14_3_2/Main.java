import java.io.*;
class MainClass{
	public static void main(String[] args){
		File f = new File("c:/MySystem/Male/K12345678.txt");
		try{
			FileReader  r = new FileReader( f );


			BufferedReader br = new BufferedReader( r );

			String  s ;
			while( ( s  = br.readLine()) != null){
				System.out.println(   s   );
			}
			br.close();
		}catch(IOException e){
			System.out.println("IO�o�Ͳ��`");
		}
	}
}
