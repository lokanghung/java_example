import java.io.*;
class MainClass{
	public static void main(String[] args){


		File f = new File("c:/Male/Person01.txt");
		File d1 = new File("c:/Male");
		File d2 = new File("c:/Female");

		if(f.isFile()) System.out.println("c:/Male/Person01.txt�O�ɮ�");
		if(f.isDirectory()) System.out.println("c:/ Male/Person01.txt�O�ؿ�");
		if(d1.isFile()) System.out.println("c:/Male�O�ɮ�");
		if(d1.isDirectory()) System.out.println("c:/Male�O�ؿ�");
		if(d2.isFile()) System.out.println("c:/Female�O�ɮ�");
		if(d2.isDirectory()) System.out.println("c:/ Female�O�ؿ�");
	}
}
