import java.io.*;
class MainClass{
  public static void main(String[] args){


	File f = new File("c:/Male/Person01.txt");
	File d1 = new File("c:/Male");
	File d2 = new File("c:/Female");

	if(f.exists()) System.out.println("c:/Male/Person01.txt�s�b");
	if(d1. exists()) System.out.println("c:/Male�s�b");
	if(d2. exists()) System.out.println("c:/Female�s�b");
  }
}
