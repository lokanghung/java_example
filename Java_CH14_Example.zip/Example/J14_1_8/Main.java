import java.io.*;
class MainClass{
	public static void main(String[] args){
		File d1 = new File("c:/MySystem");
		File d2 = new File(d1, "Male");
		File d3 = new File(d2, "Female");
		d1.mkdir();
		d2.mkdir();
		d3.mkdir();

		File f = new File(d2, "Person01.txt");
		try{ f.createNewFile();}catch(IOException e){ }


		String[] paths1 = d1.list();
		for(String p : paths1)
			System.out.println(p);

		String[] paths2 = d2.list();
		for(String p : paths2)
			System.out.println(p);
	}
}
