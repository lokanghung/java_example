import java.io.*;

class Employee extends Person{

	private String employeeID;
	private int    salary;
	transient Boss  boss;

	Employee(String id, String name, String gender,
		int age, String employeeID, int salary, Boss b){
		super(id, name, gender, age);
		this. employeeID = employeeID;
		this.salary      = salary;
		this.boss = b;
	}

	String getEmployeeID(){return employeeID;}
	void  setEmployeeID(String s){ employeeID =s;}
	int   getSalary(){return salary;}
	void  setSalary(int i){ salary =i;}

	private void writeObject(ObjectOutputStream os) throws IOException{
		os.defaultWriteObject();
		os.writeObject(boss.name);
	}


	private void readObject(java.io.ObjectInputStream is) throws IOException, ClassNotFoundException{
		is.defaultReadObject();
		boss=new Boss();
		boss.name= (String) is.readObject();
	}
}


