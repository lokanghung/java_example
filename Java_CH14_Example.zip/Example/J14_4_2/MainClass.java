import java.io.*;
class MainClass{
	public static void main(String[] args){
		File f = new File("c:/MySystem/Male/K12345678.txt");
		try{
			f.createNewFile();
			FileOutputStream os = new FileOutputStream( f );

			ObjectOutputStream oos = new ObjectOutputStream (os);
			Person p = new Person("K12345678", "Jack", "�k", 20);

			oos.writeObject(p);

			oos.close();
		}catch(IOException e){
			System.out.println(e);
		}
	}
}
