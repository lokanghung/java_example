import java.io.*;

class MainClass{
  public static void main(String[] args){

		File f = new File("C:/FileOrDIR");

  }
}
