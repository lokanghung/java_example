import java.io.*;
class MainClass{
	public static void main(String[] args){
		File f = new File("c:/Test.txt");
		try{
			f.createNewFile();
			byte[] bytes;

			bytes= (new String("���ժ����e")).getBytes();

			FileOutputStream os = new FileOutputStream( f );
			os.write(bytes);

			FileInputStream is = new FileInputStream( f );
			bytes = new byte[is.available()];
			is.read(bytes);


			System.out.println(new String(bytes));
		}catch(IOException e){ }
	}
}
