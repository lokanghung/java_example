import java.io.*;
class MainClass{
		public static void main(String[] args){
		File f = new File("c:/MySystem/Male/K12345678.txt");
		try{
			f.createNewFile();
			FileOutputStream os = new FileOutputStream( f );
			ObjectOutputStream oos = new ObjectOutputStream (os);

			Employee e1 = new Employee("K12345678", "Jack", "�k", 20, "048679", 40000);


			oos.writeObject(e1);
			oos.close();

			FileInputStream is = new FileInputStream( f );
			ObjectInputStream ois = new ObjectInputStream (is);


			Employee e2 = (Employee)ois.readObject();
			ois.close();
		}catch(IOException e){
			System.out.println(e);
		}catch(ClassNotFoundException e1){
			System.out.println(e1);
		}
	}
}
