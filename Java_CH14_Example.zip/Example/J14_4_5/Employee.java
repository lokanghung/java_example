class Employee extends Person{

	private String employeeID;
	private int    salary;

	Employee(String id, String name, String gender,
		int age, String employeeID, int salary){
		super(id, name, gender, age);
		this. employeeID = employeeID;
		this.salary      = salary;
	}

	String getEmployeeID(){return employeeID;}
	void  setEmployeeID(String s){ employeeID =s;}
	int   getSalary(){return salary;}
	void  setSalary(int i){ salary =i;}
}
