import java.io.*;
class MainClass{
  public static void main(String[] args){
		File  f  = new File("c:/MySystem/Male/K12345678.txt");

		try{
			BufferedWriter bw = new BufferedWriter( f );
		}catch(IOException e){
			System.out.println("IO�o�Ͳ��`");
		}
	}
}
