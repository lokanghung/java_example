class Boss{
  String name;

  Boss(){}
  Boss(String name){
    this.name = name;
  }
}
