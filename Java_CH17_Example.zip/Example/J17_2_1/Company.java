class Company {
	String name;
	private int cash=10000;


	static class BestCompanys{

		static Company first;
		static Company second;
	}


	Employee createEmployee(){
		return new Employee();
	}

	class Employee extends Person{
		String employeeID;
		int   salary;

		void buy(Product p){
			cash = cash - p.price;
			System.out.println("�ثe���q���{����" + cash);
		}

		void IntroduceCompany(){
			System.out.println("���u" + this.name + "�u�@��");
			System.out.println(Company.this.name);
			System.out.println("�s�Ϊ��٦�" + Company.this.cash);
		}
	}

}
