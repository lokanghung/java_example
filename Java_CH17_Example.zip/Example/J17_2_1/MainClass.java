class MainClass{
  public static void main(String[] args){

	Company com1 = new Company();
	com1.name = "Java�ѥ��������q";

	Company com2 = new Company();
	com2.name = "VB�ѥ��������q";



	Company.BestCompanys b1 = new Company.BestCompanys();
	b1.first = com1;
	b1.second = com2;


	Company.BestCompanys b2 = new Company.BestCompanys();

	System.out.println(b2.first.name);
	System.out.println(b2.second.name);




 }
}