class Person {
	String id;
	String name;
	String gender;
	int    age;
}
