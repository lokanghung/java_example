class MainClass{
  public static void main(String[] args){

	Company com = new Company();
	com.name = "Java�ѥ��������q";

	Company.Employee emp = com.new Employee();

	emp.id = "k12345678";
	emp.name = "Jack";
	emp.gender = "�k";
	emp.age = 20;
	emp.employeeID = "048679";
	emp.salary = 40000;
 }
}