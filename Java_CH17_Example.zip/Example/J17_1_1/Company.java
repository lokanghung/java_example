class Company {
String name;

  class Employee extends Person{
		String employeeID;
		int   salary;
  }
}
