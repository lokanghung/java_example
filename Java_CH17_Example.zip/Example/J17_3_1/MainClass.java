class MainClass{
  public static void main(String[] args){
		Contractor1 c1 = new Contractor1();
		c1.code();
		c1.debug();

		Contractor1 c2 = new Contractor1();
		c2.code();
		c2.debug();
 }
}