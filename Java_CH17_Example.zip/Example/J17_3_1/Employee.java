class Employee extends Person{
	String  employeeID;
	int     salary;
}
