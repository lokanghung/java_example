class Product{
  String name;
  int    price;
}
