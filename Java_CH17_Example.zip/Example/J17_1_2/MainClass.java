class MainClass{
  public static void main(String[] args){

	Employee emp;

	emp = new Employee();

 }
}