class MainClass{
  public static void main(String[] args){

	Company.BestCompanys b1 = new Company.BestCompanys();

	b1.Reason();



 }
}