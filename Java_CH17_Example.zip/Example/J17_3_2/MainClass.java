class MainClass{
  public static void main(String[] args){
		Programmer p;

		p = new Programmer("K12345678", "Jack", "�k", 20, "048679", 40000) {   } ;

		System.out.println("���u�G"+p.name);
		p.code();
		p.debug();

 }
}