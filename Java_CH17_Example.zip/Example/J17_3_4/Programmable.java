interface Programmable{
	public void code();
	public void debug();
}