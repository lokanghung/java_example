class Boss{
	void codeCommad(Programmable p){
		p.code();
	}
}
