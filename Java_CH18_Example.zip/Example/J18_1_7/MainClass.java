class MainClass{
  public static void main(String[] args){
	Employee  e1= new Employee("Jack");
	e1.start();
  }
}
