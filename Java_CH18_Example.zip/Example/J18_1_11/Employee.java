class Employee extends Thread {
	String name;
	String task;

	public Employee(String name, String task){
		this.name = name;
		this.task=task;
	}

	public void run(){
		for(int i=1; i<=5; i++){
			Thread.yield();
			System.out.println(name + "�i��u�@-" + task + "�A�����i��" + i* 20 + "%");
		}
	}
}
