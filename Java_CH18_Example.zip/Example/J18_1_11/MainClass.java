class MainClass{
  public static void main(String[] args){
	Employee e1= new Employee("Jack", "�e��");
	Employee e2= new Employee("Eric", "�g�{��");
	Employee e3= new Employee("Mary", "�]�p�e��");
	e1.start();
	e2.start();
	e3.start();

  }
}
