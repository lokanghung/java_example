class Employee extends Thread {
	String name;Company company;
	Employee(String name, Company company){
		this.name = name; this.company = company;
	}

	public void run(){
		for (int i=0; i<3; i++) company.withdraw(name, 300);
	}
}
