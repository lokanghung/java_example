class Company{

	int cash=1000;

	void withdraw(String empName, int amont){


		if( cash >= amont ){
			try{Thread.sleep(10);}catch(InterruptedException e){}
			System.out.println(empName + "�����F" + amont + "���C");
			cash=cash-amont;
		}
		System.out.println("�ѤU���s�Ϊ��G"+cash);
	}
}
