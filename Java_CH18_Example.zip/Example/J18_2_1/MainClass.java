class MainClass{
  public static void main(String[] args){

	Company com = new Company();

	Employee e1= new Employee("Jack", com);
	Employee e2= new Employee("Eric", com);
	e1.start();
	e2.start();
  }
}
