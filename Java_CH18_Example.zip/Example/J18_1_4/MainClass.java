class MainClass{
  public static void main(String[] args){
	Employee e1= new Employee("Jack");
	Employee e2= new Employee("Eric");
	Employee e3= new Employee("Mary");

	e1.run();
	e2.run();
	e3.run();

  }
}
