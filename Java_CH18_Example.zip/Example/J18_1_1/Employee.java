class Employee {
	String name;

	public Employee(String name){
		this.name = name;
	}
	void doWork(){System.out.println(name + "�}�l�u�@�C");}
}
