class Employee extends Thread{
	String name;

	public Employee(String name){
		this.name = name;
	}

}
