class MainClass{
  public static void main(String[] args){

    Company com = new Company();

	Object lock = new Object();

	Employee e1= new Employee("Jack", com, lock);
	Employee e2= new Employee("Eric", com, lock);

    e1.start();
    e2.start();

  }
}
