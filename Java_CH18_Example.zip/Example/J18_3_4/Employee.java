class Employee extends Thread {
	String name;
	Company company;
	Object lock;

	Employee(String name, Company company, Object lock){
		this.name = name; this.company = company; this.lock=lock;
	}
	public void run(){
		for (int i=0; i<3; i++) {
			synchronized(lock){
				company.withdraw(name, 300);
			}
		}
	}
}
