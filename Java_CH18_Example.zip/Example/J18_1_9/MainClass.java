class MainClass{
  public static void main(String[] args){
	Employee e1= new Employee("Jack");
	e1.start();

	try{
		e1.sleep(1000);
	}catch(InterruptedException  e){}

	System.out.println("main()��k�����{���C");

  }
}
