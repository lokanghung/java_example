class MainClass{
  public static void main(String[] args){
	Employee e= new Employee("Jack");

	Thread t = new Thread(e);
	t.start();
  }
}
