class MainClass{
  public static void main(String[] args){
	Employee e1= new Employee("Jack");
	Employee e2= new Employee("Eric");
	Employee e3= new Employee("Mary");

	e1.start();
	e2.start();
	e3.start();

  }
}
